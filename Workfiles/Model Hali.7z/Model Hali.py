import io
from PIL import Image
import PySimpleGUI as sg
from pathlib import Path
import configparser

# TITLE:        PARAMETRIC HALL MODEL
# DESCRIPTION:  THE SCRIPT GENERATES A PNG IMAGES OF A STEEL HALL WITH CHOSEN PARAMETERS
# AUTHOR:       MARTA SIENKIEWICZ
# LICENSE:      CREATIVE COMMONS (CC) 2021

# ------------------------ GLOBAL VARIABLES ------------------------ #

Resources = Path("Resources")                   # Path to resources folder
Sandwich = Path("Resources/Sandwich")           # Path to resources sandwich folder
Construction = Path("Resources/Construction")   # Path to resources construction folder

config = configparser.ConfigParser()
config.read(Resources / "config.rc")            # Configuration file

# ---------------------- FUNCTION DEFINITIONS ---------------------- #
def create_window(type):
    if type == 'Help':
        type_layout = [[sg.Text('To create an image change options in the left column and select "Submit".\nTo save your image to .png file select "Save".\n', justification='center')]]
        return sg.Window('Help', font=("Raleway", 14)).Layout(type_layout)
    elif type == 'Version':
        type_layout = [[sg.Text('AUTHOR: MARTA SIENKIEWICZ\nLICENCE: CREATIVE COMMONS (CC) 2021', justification='center')]]
        return sg.Window('Version', font=("Raleway", 14)).Layout(type_layout)

def overlay_image(foreground_list, background, x, y): # Overlaying one image over many images:
    for overlay in foreground_list:
        background.paste(overlay, (x,y), overlay)

def update_image(bio, values):
   
    # Getting hall dimentions
    segments = int(values['-FRAMES-'])
    hallWidth = int(values['-WIDTH-'])
    hallHeight = int(values['-HEIGHT-'])

    # Background image size (resizes with the hall size)
    im_width = 900 + 275 * (segments-1)
    im_height = 710 + 198 * (segments-1)

    target_image = Image.new("RGB", (im_width, im_height), (255, 255, 255)) # Creates an image with white background.

    # Loading construction and equipment images
    frame = Image.open(Construction / "frame_{0}_{1}.png".format(hallWidth, hallHeight))
    sidewall = Image.open(Sandwich / "wall_{}.png".format(hallHeight)) 
    roof = Image.open(Sandwich / "roof_{}.png".format(hallWidth))
    gablewall = Image.open(Sandwich / "gablewall_{0}_{1}.png".format(hallWidth, hallHeight))
    
    equipment_queue = []
    if values['-VIEW-']:
        equipment_queue.append(frame)
    else:
        equipment_queue.append(sidewall)
        equipment_queue.append(roof)
        equipment_queue.append(gablewall)
    
    # Main overlay loop
    for offset in range(segments):
        overlay_image(equipment_queue, target_image, 177*offset, 102*offset) # 180 105

    target_image.save("hala.png", "PNG")
    target_image.thumbnail((int(config['img size']['thumbw']), int(config['img size']['thumbh']))) 
    target_image.save(bio, format="PNG")

def main_menu():
    sg.theme('Light Gray 1') # Menu box theme
    menu_column = [
        [ # ---- 0
            sg.Text('Welcome to the ultimate steel hall generator.\n\n', justification='center') 
        ], [ # ---- 1
            sg.Text('Number of segments:') 
        ], [ # ----2
            sg.Spin(values=('1', '2', '3', '4',  '5',  '6'), initial_value=int(config['DEFAULT']['segments']), size=(20, 10), key="-FRAMES-")
        ], [ # ---- 3
            sg.Text('Hall width [m]:') 
        ], [# ----4
            sg.Spin(values=('6', '12', '18'), initial_value=int(config['DEFAULT']['width']), size=(20, 10), key="-WIDTH-")
        ], [ # ---- 5
            sg.Text('Hall height [m]:') 
        ], [# ----6
            sg.Spin(values=('3', '6'), initial_value=int(config['DEFAULT']['height']), size=(20, 10), key="-HEIGHT-")
        ], [ # ----7
            sg.Checkbox('Construction frame view', default=False, key="-VIEW-")
        ]
        ]
    viewer_column = [ # Hall view and action buttons
        [ # ----6
            sg.Image(size=(485, 375), key="-IMAGE-")
        ],[ # ----7
            sg.Submit(), sg.Save(), sg.Cancel(), sg.Help(), sg.Button('Version')
        ]
    ]
    
    layout = [ # Whole script window
    [
    sg.Column(menu_column),
    sg.VSeperator(),
    sg.Column(viewer_column),
    ]
    ]

    window = sg.Window('Steel Hall Generator', font=("Raleway", 14)).Layout(layout)

    while True:
        event, values = window.Read() # Run the window until an "event" is triggered
        if event == "Submit" or event == "Save":
            bio = io.BytesIO() # Byte stream
            update_image(bio, values)
            window["-IMAGE-"].update(data=bio.getvalue())
        elif event == "Help" or event == "Version":
            h_window = create_window(event)
            event, values = h_window.Read()
        elif event is None or event == "Cancel":
            return None

# ---------------------- MAIN ---------------------- #

if __name__ == "__main__":
    menu = main_menu()
    print(menu)
